
SELECT name, age FROM users WHERE created_at > NOW() - INTERVAL 7 DAY;
    