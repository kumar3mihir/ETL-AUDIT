
import pandas as pd

def extract_data():
    return pd.read_csv("input.csv")  # No logging

df = extract_data()
df.to_csv("output.csv", index=False)  # No logging
    