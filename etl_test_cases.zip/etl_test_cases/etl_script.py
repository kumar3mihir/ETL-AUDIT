
import pandas as pd

def extract_data():
    return pd.read_csv("input.csv")

def transform_data(df):
    df["processed_at"] = pd.Timestamp.now()
    return df

def load_data(df):
    df.to_csv("output.csv", index=False)

df = extract_data()
df = transform_data(df)
load_data(df)
    