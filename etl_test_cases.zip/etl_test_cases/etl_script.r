
data <- read.csv("input.csv")
data$processed_at <- Sys.time()
write.csv(data, "output.csv", row.names=FALSE)
    