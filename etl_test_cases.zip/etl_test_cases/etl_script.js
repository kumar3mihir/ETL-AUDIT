
console.log("Starting ETL Process...");
const fs = require('fs');
fs.copyFileSync("input.csv", "output.csv");
console.log("ETL Process Completed");
    