
#!/bin/bash
echo "Starting ETL Process"
cp input.csv output.csv
echo "ETL Process Completed"
    